# AtmoSync — Micro-Climate Analytics Dashboard

A portfolio-ready data analytics project that analyzes hourly environmental telemetry across multiple locations and converts raw sensor readings into **comfort, weather-risk, and location-comparison KPIs**.

> **Dataset Note:** The included dataset is a synthetic/public-safe dataset created for this portfolio project. It does not contain confidential Infotact Solutions data.

## Project Objective

AtmoSync focuses on understanding environmental conditions across different locations and time periods.

The project answers questions such as:

- Which locations show the most favorable environmental conditions?
- How do temperature and humidity vary over time?
- Which locations experience higher rain or wind risk?
- Which time windows have better comfort conditions?
- How can environmental data be transformed into clear, decision-ready insights?

## Tech Stack

- Python
- Pandas
- NumPy
- Matplotlib
- Streamlit
- CSV

## Project Workflow

The project follows a complete analytics workflow:

1. Load raw environmental telemetry data.
2. Clean and validate the dataset.
3. Parse timestamps and remove duplicate records.
4. Identify invalid temperature and humidity values.
5. Handle missing humidity values by location.
6. Engineer time-based features such as hour and date.
7. Calculate a comfort score using temperature and humidity.
8. Categorize precipitation and wind risk.
9. Generate KPI tables and analytical visualizations.
10. Present the results through an interactive Streamlit dashboard.

## Key KPIs

The dashboard focuses on the following indicators:

- Average Temperature
- Average Humidity
- Average Wind Speed
- Total Precipitation
- Average Comfort Score
- High-Rain Observations
- High-Wind Observations
- Location-wise Environmental Comparison

### Comfort Score

The **Comfort Score** is a portfolio metric designed to summarize how close temperature and humidity are to a selected comfortable range.

It is an analytical indicator created for this project and is **not a medical or scientific comfort standard**.

## Analysis & Visualizations

The project includes analytical outputs for:

- Daily environmental trends
- Location-wise comparison
- Temperature and humidity relationships
- Correlation analysis
- Comfort patterns by hour
- Location-level KPI summaries
- Hourly environmental profiles

## Repository Contents

The repository contains:

- `analysis.py` — data cleaning, feature engineering, KPI calculation, and analysis
- `dashboard.py` — interactive Streamlit dashboard
- `atmosync_raw.csv` — raw project dataset
- `atmosync_clean.csv` — cleaned dataset
- Analytical PNG visualizations
- KPI and hourly profile CSV outputs
- Data dictionary and project documentation
- `requirements.txt` — Python dependencies

## Run Locally

Clone the repository and install the required dependencies:

```bash
pip install -r requirements.txt
